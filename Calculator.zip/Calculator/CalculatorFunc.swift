//
//  CalculatorFunc.swift
//  Calculator
//
//  Created by Sajin Joseph on 24/09/22.
//

import Foundation
class calculatorfunc{
    public var t1: Int = 0;
    public var op:String = ""
    
}
